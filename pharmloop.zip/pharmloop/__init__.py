"""PharmLoop — Recurrent oscillatory reasoning engine for drug interaction checking."""
